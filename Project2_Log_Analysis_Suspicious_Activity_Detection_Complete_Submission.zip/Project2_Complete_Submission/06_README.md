# Project 2 - Log Analysis and Suspicious Activity Detection

## Student
Raju G H | BTech in Cyber Security, 6th Semester | GM University, Davangere

## Objective
Parse security/application logs, normalize important fields, apply transparent detection rules, and display severity-based alerts.

## Detection rules
1. Multiple failed logins - HIGH
2. Successful login after repeated failures - HIGH
3. Multiple usernames from one source IP - MEDIUM
4. Restricted resource access - HIGH
5. High request frequency - MEDIUM
6. Repeated HTTP 4xx/5xx errors - MEDIUM
7. Flagged source IP - CRITICAL
8. Unusual login time - LOW

## Run in VS Code terminal
From the project `src` folder:

    python -m pip install -r ../requirements.txt
    python app.py

Open http://127.0.0.1:5001

The sample data is in `data/sample_security.log`. This is an educational/synthetic lab dataset.
